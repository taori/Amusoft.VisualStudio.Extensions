using System;
using System.Text.RegularExpressions;
using $ext_safeprojectname$.Application.Dependencies.Setup;
using $ext_safeprojectname$.Application.Dependencies.UI;
using $ext_safeprojectname$.Framework.DependencyInjection;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Composer;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Environment;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.ViewMapping;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity.ViewModelBehaviors;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Navigation;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.UI;
using $ext_safeprojectname$.Framework.Mvvm.Integration.Environment;
using $ext_safeprojectname$.Framework.Mvvm.Integration.ViewMapping;
using $ext_safeprojectname$.Framework.Mvvm.Interactivity.ViewModelBehaviors;
using $ext_safeprojectname$.Framework.Mvvm.Navigation;
using Microsoft.Extensions.DependencyInjection;
using NLog;

namespace $ext_safeprojectname$.Application.Dependencies.Registrars
{
	public class ShellRegistrar : IServiceRegistrar
	{
		private static readonly ILogger Log = LogManager.GetLogger(nameof(ShellRegistrar));

		/// <inheritdoc />
		public void Register(IServiceCollection services)
		{
			Singleton<IDialogService, MetroDialogService>(services);
			Singleton<INavigationService, NavigationService>(services);
			Singleton<IInjectionAssemblyLoader, InjectionAssemblyLoader>(services);
			Singleton<IRegionManager, RegionManager>(services);
			Singleton<IWindowManager, WindowManager>(services);
			Singleton<IDisplayCoordinatorFactory, DisplayCoordinatorFactory>(services);
			Singleton<IBehaviorRunner, BehaviorRunner>(services);
			Singleton<ISettingsStorage, SettingsStorage>(services);

			Transient<IServiceContext, ServiceContext>(services);
			Transient<IViewModelWindowFactory, WindowFactory>(services);
			services.AddTransient<IRegexDataTemplatePatternProvider>(CreateDefaultConventionPattern);
		}

		private void Singleton<TService, TImplementation>(IServiceCollection services) where TService : class where TImplementation : class, TService
		{
			Log.Debug($"Registering [Singleton] [{typeof(TImplementation)}] -> [{typeof(TService)}].");
			services.AddSingleton<TService, TImplementation>();
		}
		private void Transient<TService, TImplementation>(IServiceCollection services) where TService : class where TImplementation : class, TService
		{
			Log.Debug($"Registering [Transient] [{typeof(TImplementation)}] -> [{typeof(TService)}].");
			services.AddTransient<TService, TImplementation>();
		}

		private static InlineMvvmPattern CreateDefaultConventionPattern(IServiceProvider provider)
		{
			// TODO: change the contents of this regex to match your namespace
			return new InlineMvvmPattern(
				new Regex("(?<ns1>Company\\.Desktop\\.)(?<ignore>ViewModels)(?<ns2>.*?)(?<class>\\.[^.]+)(?=ViewModel$)", RegexOptions.Compiled, TimeSpan.FromMilliseconds(30)), 
				new Regex("(?<ns1>Company\\.Desktop\\.)(?<ignore>Application\\.Views)(?<ns2>.*?)(?<class>\\.[^.]+)(?=View$|Page$|Control$|Window$)", RegexOptions.Compiled, TimeSpan.FromMilliseconds(30))
			);
		}
	}
}