﻿
using System.Runtime.InteropServices;
using System.Windows;

[assembly: ComVisible(false)]
[assembly: ThemeInfo(
	ResourceDictionaryLocation.None, //Speicherort der designspezifischen Ressourcenwörterbücher
									 //(wird verwendet, wenn eine Ressource auf der Seite nicht gefunden wird,
									 // oder in den Anwendungsressourcen-Wörterbüchern nicht gefunden werden kann.)
	ResourceDictionaryLocation.SourceAssembly //Speicherort des generischen Ressourcenwörterbuchs
											  //(wird verwendet, wenn eine Ressource auf der Seite nicht gefunden wird,
											  // designspezifischen Ressourcenwörterbuch nicht gefunden werden kann.)
)]