namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity.ViewModelBehaviors
{
	public interface IWindowClosingBehavior : IAsyncBehavior<IWindowClosingBehaviorContext>
	{
	}
}