using System.Windows;
using $ext_safeprojectname$.Framework.DependencyInjection;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Composer
{
	[InheritedExport(typeof(IViewComposerFactory))]
	public interface IViewComposerFactory
	{
		IViewComposer Create(FrameworkElement control);
	}
}