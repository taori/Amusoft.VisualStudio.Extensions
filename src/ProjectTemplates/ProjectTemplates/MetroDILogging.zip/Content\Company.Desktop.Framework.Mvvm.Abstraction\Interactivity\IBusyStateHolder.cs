namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity
{
	public interface IBusyStateHolder
	{
		IBusyState LoadingState { get; }
	}
}