using System;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Environment
{
	public interface IServiceContext
	{
		IServiceProvider ServiceProvider { get; }
	}
}