using Microsoft.Extensions.DependencyInjection;

namespace $ext_safeprojectname$.Framework.DependencyInjection
{
	public interface IServiceRegistrar
	{
		void Register(IServiceCollection services);
	}
}