using $ext_safeprojectname$..Jobs;
using Microsoft.Extensions.DependencyInjection;

namespace $ext_safeprojectname$.
{
	public class ServiceBuilder
	{
		public void Build(IServiceCollection serviceCollection)
		{
			serviceCollection.AddScoped<ITest>(sp => new TestImpl());
		}
	}
}