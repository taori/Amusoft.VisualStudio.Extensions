namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.ViewModel
{
	public interface IConfigureWindow
	{
		void Configure(IWindowViewModel window);
	}
}