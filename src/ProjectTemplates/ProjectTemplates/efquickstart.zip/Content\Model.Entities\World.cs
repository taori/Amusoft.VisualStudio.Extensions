using System;

namespace $ext_safeprojectname$.Entities
{
	public class World
	{
		public int Id { get; set; }
	}
}
