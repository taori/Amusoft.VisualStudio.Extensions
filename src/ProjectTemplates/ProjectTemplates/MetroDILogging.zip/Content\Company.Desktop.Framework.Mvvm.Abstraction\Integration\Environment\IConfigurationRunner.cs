using $ext_safeprojectname$.Framework.DependencyInjection;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Environment
{
	[InheritedExport(typeof(IConfigurationRunner), LifeTime = LifeTime.Singleton)]
	public interface IConfigurationRunner
	{
		void Execute();
	}
}