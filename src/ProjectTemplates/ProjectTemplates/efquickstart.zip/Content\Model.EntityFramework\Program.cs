namespace $ext_safeprojectname$.EntityFramework
{
	class Program
	{
		static void Main(string[] args)
		{
		}
	}
}
