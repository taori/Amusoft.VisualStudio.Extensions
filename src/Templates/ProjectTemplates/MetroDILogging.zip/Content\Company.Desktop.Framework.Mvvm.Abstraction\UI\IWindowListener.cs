using System.ComponentModel;
using System.Windows;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.UI
{
	public interface IWindowListener
	{
		void NotifyClosed();
		void NotifyClosing(CancelEventArgs args);
		void NotifyWindowStateChange(WindowState args);
		void NotifyLocationChanged(Point args);
		void NotifySizeChanged(SizeChangedEventArgs args);
	}
}