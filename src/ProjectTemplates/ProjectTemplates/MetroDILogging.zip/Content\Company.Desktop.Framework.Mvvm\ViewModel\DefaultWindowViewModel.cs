using $ext_safeprojectname$.Framework.Mvvm.Abstraction.ViewModel;
using JetBrains.Annotations;

namespace $ext_safeprojectname$.Framework.Mvvm.ViewModel
{
	public class DefaultWindowViewModel : WindowViewModelBase
	{
		/// <inheritdoc />
		public DefaultWindowViewModel([NotNull] IWindowContentViewModel content) : base(content)
		{
		}
	}
}