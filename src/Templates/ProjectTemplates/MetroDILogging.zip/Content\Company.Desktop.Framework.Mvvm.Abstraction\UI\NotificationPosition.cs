namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.UI
{
	public enum NotificationPosition
	{
		BottomRight,
		Bottom,
		BottomLeft,
		Left,
		TopLeft,
		Top,
		TopRight,
		Right
	}
}