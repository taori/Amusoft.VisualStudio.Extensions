
namespace $ext_safeprojectname$.Models.Abstraction.Entities
{
	public interface ISampleData
	{
		string Value1 { get; set; }

		string Value2 { get; set; }
	}
}