using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.ViewMapping;

namespace $ext_safeprojectname$.Framework.Mvvm.Integration.ViewMapping
{
	public class WindowArguments : ICoordinationArguments
	{
		/// <inheritdoc />
		public WindowArguments(string windowId)
		{
			WindowId = windowId;
		}

		public string WindowId { get; }
	}
}