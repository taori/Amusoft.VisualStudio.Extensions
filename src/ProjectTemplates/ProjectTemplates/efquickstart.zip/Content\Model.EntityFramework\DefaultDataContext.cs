using Microsoft.EntityFrameworkCore;
using $ext_safeprojectname$.Entities;

namespace $ext_safeprojectname$.EntityFramework
{
	public class DefaultDataContext : DbContext
	{
		/// <inheritdoc />
		public DefaultDataContext(DbContextOptions options) : base(options)
		{
		}

		public DbSet<World> Worlds { get; set; }

		/// <inheritdoc />
		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			base.OnConfiguring(optionsBuilder);
#if DEBUG
			optionsBuilder.EnableDetailedErrors();
			optionsBuilder.EnableSensitiveDataLogging();
#endif
		}
	}
}