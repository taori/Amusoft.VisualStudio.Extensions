using $ext_safeprojectname$.Models.Abstraction.Entities;

namespace $ext_safeprojectname$.Models.Entities
{
	public class SampleData : ISampleData
	{
		/// <inheritdoc />
		public SampleData()
		{
		}

		/// <inheritdoc />
		public SampleData(string value1, string value2)
		{
			Value1 = value1;
			Value2 = value2;
		}

		public string Value1 { get; set; }

		public string Value2 { get; set; }
	}
}
