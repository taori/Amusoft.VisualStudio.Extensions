﻿using System.Runtime.InteropServices;

[assembly: ComVisible(false)]
[assembly: Guid("8ad183c4-4e16-4719-bf23-c26f7ba947a7")]
