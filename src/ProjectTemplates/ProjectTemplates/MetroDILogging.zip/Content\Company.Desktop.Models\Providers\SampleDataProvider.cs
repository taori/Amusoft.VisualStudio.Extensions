using System.Collections.Generic;
using System.Threading.Tasks;
using $ext_safeprojectname$.Models.Abstraction.Entities;
using $ext_safeprojectname$.Models.Abstraction.Providers;
using $ext_safeprojectname$.Models.Entities;

namespace $ext_safeprojectname$.Models.Providers
{
	public class SampleDataProvider : ISampleDataProvider
	{
		/// <inheritdoc />
		public Task<IEnumerable<ISampleData>> GetAllAsync(int count)
		{
			var items = new List<SampleData>();
			for (int i = 0; i < count; i++)
			{
				items.Add(new SampleData($"row {i} value 1", $"row {i} value 2"));
			}

			return Task.FromResult(items as IEnumerable<ISampleData>);
		}
	}
}
