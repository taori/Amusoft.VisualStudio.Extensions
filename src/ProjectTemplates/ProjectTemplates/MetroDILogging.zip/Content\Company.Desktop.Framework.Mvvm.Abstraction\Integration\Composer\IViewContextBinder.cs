
using $ext_safeprojectname$.Framework.DependencyInjection;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Composer
{
	[InheritedExport(typeof(IViewContextBinder))]
	public interface IViewContextBinder
	{
		bool TryBind(IViewCompositionContext context);
	}
}