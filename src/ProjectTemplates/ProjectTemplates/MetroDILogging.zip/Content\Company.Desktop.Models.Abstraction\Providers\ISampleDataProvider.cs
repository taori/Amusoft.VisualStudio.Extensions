
using System.Collections.Generic;
using System.Threading.Tasks;
using $ext_safeprojectname$.Framework.DataAccess;
using $ext_safeprojectname$.Framework.DependencyInjection;
using $ext_safeprojectname$.Models.Abstraction.Entities;

namespace $ext_safeprojectname$.Models.Abstraction.Providers
{
	[InheritedExport(typeof(ISampleDataProvider))]
	public interface ISampleDataProvider : IDataProvider
	{
		Task<IEnumerable<ISampleData>> GetAllAsync(int count);
	}
}