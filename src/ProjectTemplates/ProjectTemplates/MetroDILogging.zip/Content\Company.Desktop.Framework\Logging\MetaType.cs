namespace $ext_safeprojectname$.Framework.Logging
{
	public enum MetaType
	{
		None,
		System
	}
}