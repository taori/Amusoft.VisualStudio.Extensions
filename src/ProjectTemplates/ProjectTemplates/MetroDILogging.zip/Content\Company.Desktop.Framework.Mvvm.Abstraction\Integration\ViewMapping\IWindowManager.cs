using System.Windows;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.ViewMapping
{
	public interface IWindowManager
	{
		void RegisterWindow(Window window, string id);
		bool TryGetWindow(string id, out Window window);
	}
}