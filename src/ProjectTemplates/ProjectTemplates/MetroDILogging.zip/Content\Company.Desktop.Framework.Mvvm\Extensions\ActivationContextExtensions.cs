using System.Threading.Tasks;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Navigation;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.ViewModel;
using Microsoft.Extensions.DependencyInjection;

namespace $ext_safeprojectname$.Framework.Mvvm.Extensions
{
	public static class ActivationContextExtensions
	{
		public static Task<bool> NavigateAsync(this IActivationContext context, IWindowViewModel viewModel, string windowId)
		{
			return context.ServiceProvider.GetService<INavigationService>().OpenWindowAsync(viewModel, windowId);
		}
	}
}