using System;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity.ViewModelBehaviors
{
	public interface IWindowClosingBehaviorContext : IBehaviorArgument
	{
		object ViewModel { get; }
		bool Cancelled { get; }
		IServiceProvider ServiceProvider { get; }
		void Cancel();
	}
}