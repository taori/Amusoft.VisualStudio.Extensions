using System;
using System.Collections.Generic;
using $ext_safeprojectname$.Framework.DependencyInjection;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Environment
{
	[InheritedExport(typeof(IViewModelTypeSource), LifeTime = LifeTime.Singleton)]
	public interface IViewModelTypeSource
	{
		IEnumerable<Type> GetValues();
	}
}