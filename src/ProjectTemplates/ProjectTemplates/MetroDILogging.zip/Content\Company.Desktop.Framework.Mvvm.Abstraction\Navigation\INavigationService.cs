using System.Threading.Tasks;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.ViewModel;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Navigation
{
	public interface INavigationService
	{
		Task<bool> OpenWindowAsync(IWindowViewModel viewModel, string windowId);
	}
}