using System.Collections.Generic;
using System.Reflection;
using $ext_safeprojectname$.Framework.Controls;
using $ext_safeprojectname$.Framework.DataAccess;
using $ext_safeprojectname$.Framework.DependencyInjection;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.ViewMapping;
using $ext_safeprojectname$.Framework.Mvvm.Integration.ViewMapping;
using $ext_safeprojectname$.Models.Abstraction.Providers;
using $ext_safeprojectname$.Models.Providers;
using $ext_safeprojectname$.Shared.Utility;

namespace $ext_safeprojectname$.Application.Dependencies.Setup
{
	public class InjectionAssemblyLoader : IInjectionAssemblyLoader
	{
		/// <inheritdoc />
		public IEnumerable<Assembly> GetAssemblies()
		{
			yield return typeof(IDataProvider).Assembly;
			yield return typeof(ISampleDataProvider).Assembly;
			yield return typeof(SampleDataProvider).Assembly;
			yield return typeof(DependencyContainer).Assembly;
			yield return typeof(IRegionManager).Assembly;
			yield return typeof(RegionManager).Assembly;
			yield return typeof(FileHelper).Assembly;
			yield return typeof(OverlayPanel).Assembly;
		}
	}
}