using System.Threading.Tasks;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity.ViewModelBehaviors;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.UI;
using Microsoft.Extensions.DependencyInjection;

namespace $ext_safeprojectname$.Framework.Mvvm.Interactivity.ViewModelBehaviors
{
	public class ConfirmContentChangingBehavior : AsyncBehaviorBase<IContentChangingBehaviorContext>
	{
		/// <inheritdoc />
		protected override async Task OnExecuteAsync(IContentChangingBehaviorContext context)
		{
			if (!await context.ServiceProvider.GetRequiredService<IDialogService>().YesNoAsync(context.OldViewModel, "Change content?"))
				context.Cancel();
		}
	}
}