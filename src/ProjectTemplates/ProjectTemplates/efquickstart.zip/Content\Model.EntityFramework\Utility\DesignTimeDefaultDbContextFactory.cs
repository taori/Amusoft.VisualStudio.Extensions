using Microsoft.EntityFrameworkCore.Design;

namespace $ext_safeprojectname$.EntityFramework.Utility
{
	public class DesignTimeDefaultDbContextFactory : IDesignTimeDbContextFactory<DefaultDataContext>
	{
		/// <inheritdoc />
		public DefaultDataContext CreateDbContext(string[] args)
		{
			return DefaultDataContextFactory.Create(DefaultDataContextFactory.ContextType.Design);
		}
	}
}