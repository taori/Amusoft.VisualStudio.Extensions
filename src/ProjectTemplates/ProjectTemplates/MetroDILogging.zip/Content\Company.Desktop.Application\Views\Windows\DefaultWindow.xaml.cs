namespace $ext_safeprojectname$.Application.Views.Windows
{
	/// <summary>
	/// Interaktionslogik für DefaultWindow.xaml
	/// </summary>
	public partial class DefaultWindow 
	{
		public DefaultWindow()
		{
			InitializeComponent();
		}
	}
}
