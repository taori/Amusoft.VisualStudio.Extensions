namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.UI
{
	public interface INotification
	{
		NotificationPosition Position { get; }

		NotificationTarget Target { get; }
	}
}