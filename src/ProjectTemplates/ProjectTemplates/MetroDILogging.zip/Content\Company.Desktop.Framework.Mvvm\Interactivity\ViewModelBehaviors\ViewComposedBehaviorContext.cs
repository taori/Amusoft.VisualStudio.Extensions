using System;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Composer;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Environment;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity.ViewModelBehaviors;
using JetBrains.Annotations;

namespace $ext_safeprojectname$.Framework.Mvvm.Interactivity.ViewModelBehaviors
{
	public class ViewComposedBehaviorContext : IViewComposedBehaviorContext
	{
		public IViewCompositionContext CompositionContext { get; }
		public IServiceContext ServiceContext { get; }

		public ViewComposedBehaviorContext([NotNull] IViewCompositionContext compositionContext, [NotNull] IServiceContext serviceContext)
		{
			CompositionContext = compositionContext ?? throw new ArgumentNullException(nameof(compositionContext));
			ServiceContext = serviceContext ?? throw new ArgumentNullException(nameof(serviceContext));
		}
	}
}