using System;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity
{
	public interface IDeactivationContext
	{
		IServiceProvider ServiceProvider { get; }

		bool Cancelled { get; }

		void Cancel();
	}
}