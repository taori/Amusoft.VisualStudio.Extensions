using System;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Environment;

namespace $ext_safeprojectname$.Framework.Mvvm.Integration.Environment
{
	public class ServiceContext : IServiceContext
	{
		/// <inheritdoc />
		public ServiceContext(IServiceProvider serviceProvider)
		{
			ServiceProvider = serviceProvider;
		}

		/// <inheritdoc />
		public IServiceProvider ServiceProvider { get; }
	}
}