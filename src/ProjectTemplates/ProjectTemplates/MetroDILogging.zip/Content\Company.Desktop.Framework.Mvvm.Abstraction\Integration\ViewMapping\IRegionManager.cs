using System.Windows;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.ViewMapping
{
	public interface IRegionManager
	{
		FrameworkElement GetControl(object regionViewModelHolder, string regionName);
		FrameworkElement GetHostingWindow(object viewModel);
	}
}