using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.ViewModel
{
	public interface IContentViewModel : IActivateable
	{
	}
}