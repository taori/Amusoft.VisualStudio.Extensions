using NLog.Targets;

namespace $ext_safeprojectname$.Application.Dependencies.Logging
{
	public static class LogConfiguration
	{
		public static void RegisterTargets()
		{
			Target.Register("Notification", typeof(NotificationTarget));
		}
	}
}