using System.Windows;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.ViewMapping;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Composer
{
	public interface IViewCompositionContext
	{
		FrameworkElement Control { get; }

		object DataContext { get; }

		ICoordinationArguments CoordinationArguments { get; }
	}
}