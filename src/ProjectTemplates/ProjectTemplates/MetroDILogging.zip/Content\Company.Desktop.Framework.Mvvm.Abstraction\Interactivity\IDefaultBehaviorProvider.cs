using System.Collections.Generic;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity.ViewModelBehaviors;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity
{
	public interface IDefaultBehaviorProvider
	{
		IEnumerable<IBehavior> GetDefaultBehaviors();
	}
}