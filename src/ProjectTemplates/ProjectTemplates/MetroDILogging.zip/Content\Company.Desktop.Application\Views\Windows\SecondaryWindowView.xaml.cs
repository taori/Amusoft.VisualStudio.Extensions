using System.Windows.Controls;

namespace $ext_safeprojectname$.Application.Views.Windows
{
    /// <summary>
    /// Interaktionslogik für SecondaryWindowView.xaml
    /// </summary>
    public partial class SecondaryWindowView : UserControl
    {
        public SecondaryWindowView()
        {
            InitializeComponent();
        }
    }
}
