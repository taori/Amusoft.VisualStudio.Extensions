using System.Text.RegularExpressions;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.ViewMapping
{
	public interface IRegexDataTemplatePatternProvider
	{
		Regex ViewModelTypeRegex { get; }
		Regex ViewTypeRegex { get; }
	}
}