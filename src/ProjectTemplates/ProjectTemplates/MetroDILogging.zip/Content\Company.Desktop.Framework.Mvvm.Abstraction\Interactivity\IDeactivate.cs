using System.Threading.Tasks;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity
{
	public interface IDeactivate
	{
		Task DeactivateAsync(IDeactivationContext context);

		event AsyncEventHandler OnDeactivated;
	}
}