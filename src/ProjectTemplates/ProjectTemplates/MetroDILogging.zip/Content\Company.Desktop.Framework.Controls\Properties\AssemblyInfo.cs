using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Markup;

[assembly: ComVisible(false)]
[assembly:ThemeInfo(
    ResourceDictionaryLocation.None, 
    ResourceDictionaryLocation.SourceAssembly
)]
[assembly: XmlnsPrefix("http://schemas.localcontrols.com/winfx/2006/xaml/presentation", "framework")]
[assembly: XmlnsDefinition("http://schemas.localcontrols.com/winfx/2006/xaml/presentation", "$ext_safeprojectname$.Framework.Controls")]