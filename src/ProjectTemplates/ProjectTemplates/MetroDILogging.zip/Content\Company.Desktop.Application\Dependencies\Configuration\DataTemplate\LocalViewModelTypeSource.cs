using System;
using System.Collections.Generic;
using System.Linq;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Environment;

namespace $ext_safeprojectname$.Application.Dependencies.Configuration.DataTemplate
{
	public class LocalViewModelTypeSource : IViewModelTypeSource
	{
		/// <inheritdoc />
		public IEnumerable<Type> GetValues()
		{
			return typeof(ViewModels.Common.RegionNames).Assembly.ExportedTypes.Where(d => d.FullName.StartsWith("$ext_safeprojectname$.ViewModels"));
		}
	}
}