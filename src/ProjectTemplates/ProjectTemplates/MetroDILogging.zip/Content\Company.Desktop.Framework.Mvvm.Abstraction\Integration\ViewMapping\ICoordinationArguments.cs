namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.ViewMapping
{
	public interface ICoordinationArguments { }
}