using System.Threading.Tasks;
using System.Windows;
using $ext_safeprojectname$.Framework.DependencyInjection;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Composer
{
	[InheritedExport(typeof(IViewComposer))]
	public interface IViewComposer
	{
		/// <summary>
		/// Order in which the Composer is prioritized for a specific dataContext
		/// </summary>
		int Priority { get; }

		Task<bool> ComposeAsync(IViewCompositionContext context);

		bool CanHandle(FrameworkElement control);
	}
}