
namespace $ext_safeprojectname$.Framework.DataAccess
{
	public interface IDataProvider
	{
		
	}
}