using System.Windows.Controls;

namespace $ext_safeprojectname$.Application.Views.Windows
{
    /// <summary>
    /// Interaktionslogik für MainView.xaml
    /// </summary>
    public partial class MainView : UserControl
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}
