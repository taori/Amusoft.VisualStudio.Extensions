using System;
using System.Collections.Generic;
using $ext_safeprojectname$.Framework.DependencyInjection;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Environment
{
	[InheritedExport(typeof(IViewTypeSource), LifeTime = LifeTime.Singleton)]
	public interface IViewTypeSource
	{
		IEnumerable<Type> GetValues();
	}
}