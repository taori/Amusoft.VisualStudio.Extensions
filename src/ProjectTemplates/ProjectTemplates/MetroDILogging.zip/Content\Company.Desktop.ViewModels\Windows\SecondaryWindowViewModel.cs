

using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity.ViewModelBehaviors;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.ViewModel;
using $ext_safeprojectname$.Framework.Mvvm.Interactivity.ViewModelBehaviors;
using $ext_safeprojectname$.Framework.Mvvm.ViewModel;

namespace $ext_safeprojectname$.ViewModels.Windows
{
	public class SecondaryWindowViewModel : WindowContentViewModelBase, IConfigureWindow
	{
		private byte[] _someMemory;
		
		/// <inheritdoc />
		protected override async Task OnActivateAsync(IActivationContext context)
		{
			_someMemory = new byte[200000000];
			await Task.Delay(3000);
			Window.Title = $"Title updated: {DateTime.Now.ToString("F")} {_someMemory.Length}";
		}

		/// <inheritdoc />
		public override IEnumerable<IBehavior> GetDefaultBehaviors()
		{
			yield return new RestoreWindowDimensionsBehavior();
			yield return new DisposeOnCloseBehavior();
		}

		/// <inheritdoc />
		public override string GetTitle()
		{
			return $"This is a secondary window";
		}

		/// <inheritdoc />
		public void Configure(IWindowViewModel window)
		{
			window.ShowInTaskbar = false;
		}
	}
}