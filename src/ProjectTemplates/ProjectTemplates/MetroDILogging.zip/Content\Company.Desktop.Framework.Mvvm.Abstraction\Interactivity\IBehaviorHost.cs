using System;
using System.Collections.Generic;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity.ViewModelBehaviors;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity
{
	public interface IBehaviorHost : IDisposable
	{
		List<IBehavior> Behaviors { get; }
	}
}