namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.UI
{
	public enum NotificationTarget
	{
		PrimaryScreen,
		CurrentFocusedWindow
	}
}