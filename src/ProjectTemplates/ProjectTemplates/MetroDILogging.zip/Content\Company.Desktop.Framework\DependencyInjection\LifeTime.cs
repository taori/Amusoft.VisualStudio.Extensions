namespace $ext_safeprojectname$.Framework.DependencyInjection
{
	public enum LifeTime
	{
		PerRequest,
		PerScope,
		Singleton
	}
}