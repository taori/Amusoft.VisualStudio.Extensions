namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.ViewModel
{
	public interface IWindowSetter
	{
		void Set(IWindowViewModel window);
	}
}