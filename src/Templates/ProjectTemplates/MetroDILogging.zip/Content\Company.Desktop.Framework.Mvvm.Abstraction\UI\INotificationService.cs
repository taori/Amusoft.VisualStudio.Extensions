using $ext_safeprojectname$.Framework.DependencyInjection;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.UI
{
	[InheritedMefExport(typeof(INotificationService))]
	public interface INotificationService
	{
		void Display(INotification notification);
	}
}