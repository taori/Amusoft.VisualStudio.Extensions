using System;
using System.Windows;
using $ext_safeprojectname$.Application.Views.Windows;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Composer;
using $ext_safeprojectname$.Framework.Mvvm.ViewModel;

namespace $ext_safeprojectname$.Application.Dependencies.UI
{
	public class WindowFactory : IViewModelWindowFactory
	{
		/// <inheritdoc />
		public bool CanCreateWindow(object dataContext)
		{
			if (dataContext == null)
			{
				throw new ArgumentNullException(nameof(dataContext), nameof(dataContext));
			}

			return true;
		}

		/// <inheritdoc />
		public Window CreateWindow(object dataContext)
		{
			if(dataContext is DefaultWindowViewModel)
				return new DefaultWindow();

			return new DefaultWindow();
		}
	}
}