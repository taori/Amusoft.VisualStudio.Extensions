using System;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Composer;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity.ViewModelBehaviors
{
	public interface IWindowClosedBehaviorContext : IBehaviorArgument
	{
		object ViewModel { get; }

		IServiceProvider ServiceProvider { get; }

		IViewCompositionContext Context { get; }
	}
}