using System.Windows.Controls;

namespace $ext_safeprojectname$.Application.Views.Controls
{
	/// <summary>
	/// Interaktionslogik für SampleDataOverview.xaml
	/// </summary>
	public partial class SampleDataOverviewView : UserControl
	{
		public SampleDataOverviewView()
		{
			InitializeComponent();
		}
	}
}
