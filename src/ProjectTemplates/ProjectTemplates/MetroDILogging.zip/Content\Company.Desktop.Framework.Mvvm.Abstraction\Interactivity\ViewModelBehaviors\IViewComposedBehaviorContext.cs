using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Composer;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Environment;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity.ViewModelBehaviors
{
	public interface IViewComposedBehaviorContext : IBehaviorArgument
	{
		IViewCompositionContext CompositionContext { get; }
		IServiceContext ServiceContext { get; }
	}
}