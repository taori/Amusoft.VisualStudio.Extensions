using $ext_safeprojectname$.Framework.Mvvm.ViewModel;
using $ext_safeprojectname$.Models.Abstraction.Entities;

namespace $ext_safeprojectname$.ViewModels.Controls
{
	public class SampleDataViewModel : ViewModelBase
	{
		public ISampleData Data { get; }

		public SampleDataViewModel(ISampleData data)
		{
			Data = data;
		}
	}
}