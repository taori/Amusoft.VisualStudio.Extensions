using System.Windows;
using $ext_safeprojectname$.Framework.DependencyInjection;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Composer
{
	[InheritedMefExport(typeof(IViewComposerHook))]
	public interface IViewComposerHook
	{
		void Execute(FrameworkElement control, object dataContext);
	}
}