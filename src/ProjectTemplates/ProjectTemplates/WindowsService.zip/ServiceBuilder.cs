﻿using $safeprojectname$.Jobs;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$
{
	public class ServiceBuilder
	{
		public void Build(IServiceCollection serviceCollection)
		{
			serviceCollection.AddScoped<ITest>(sp => new TestImpl());
		}
	}
}