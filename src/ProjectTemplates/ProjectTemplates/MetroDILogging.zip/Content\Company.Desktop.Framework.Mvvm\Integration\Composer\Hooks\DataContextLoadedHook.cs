using System.Windows;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Integration.Composer;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity;
using $ext_safeprojectname$.Framework.Mvvm.Abstraction.ViewModel;
using $ext_safeprojectname$.Framework.Mvvm.Interactivity.ViewModelBehaviors;

namespace $ext_safeprojectname$.Framework.Mvvm.Integration.Composer.Hooks
{
	public class DataContextLoadedHook : IViewComposerHook
	{
		/// <inheritdoc />
		public void Execute(FrameworkElement control, object dataContext)
		{
			if (dataContext is IBehaviorHost activateable)
			{
				activateable.Behaviors.Add(new ActivationBehavior());

				if (control is Window window && dataContext is IWindowViewModel windowViewModel)
				{
					if(windowViewModel.Content.ClaimMainWindowOnOpen)
						Application.Current.MainWindow = window;

					window.ResizeMode = windowViewModel.ResizeMode;
				}
			}

			if(dataContext is IWindowViewModel subViewModel)
				Execute(control, subViewModel.Content);
		}
	}
}