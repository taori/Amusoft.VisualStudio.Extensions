using $ext_safeprojectname$.Framework.Mvvm.Abstraction.Interactivity;

namespace $ext_safeprojectname$.Framework.Mvvm.Abstraction.ViewModel
{
	public interface IWindowContentViewModel : IContentViewModel, IDefaultBehaviorProvider
	{
		IWindowViewModel Window { get; }
		bool ClaimMainWindowOnOpen { get; }
		string GetTitle();
	}
}